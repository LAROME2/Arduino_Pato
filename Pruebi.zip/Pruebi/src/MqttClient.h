#pragma once

#ifndef MqttClient_h
#define MqttClient_h

#include <PubSubClient.h>
#include <WiFi.h>
#include <vector>
#include <Arduino.h>


class MqttClient {
public:
    //const char *topicEntrada, const char *topicSalida
    MqttClient(const char *topicEntrada, const char *topicSalida);
    ~MqttClient(); // Declarar un destructor
    void setup();
    void reconnect();
    void Publish(float t);
    void callback(char *topic, byte *payload, unsigned int lenght);
    void client_loop();

private:
    const int MSG_BUFFER_SIZE = 80;
    std::vector<char> msg;            // Vector para almacenar las muestras
    const char *topicSalida;
    const char *topicEntrada;
    const char *mqtt_server = "broker.mqtt-dashboard.com";
    
    WiFiClient espClient;
    PubSubClient *client;

};

#endif
