#include <PubSubClient.h>
#include <WiFi.h>
#include "MqttClient.h"



MqttClient::MqttClient(const char *topicEntrada, const char *topicSalida){
// const char *topicEntrada, const char *topicSalida)
//   : topicEntrada(topicEntrada), topicSalida(topicSalida) 
    // WiFiClient espClient;
    // PubSubClient client(espClient);
    client = new PubSubClient(espClient); // Inicializar como puntero
}

void MqttClient::client_loop() {
  if (!client->connected()) {
        reconnect();
    }
  client->loop();
}

MqttClient::~MqttClient() {
    if (client){
      delete client;
    }
}

void MqttClient::setup() {
    //WiFiClient espClient;
    client->setServer(mqtt_server,1883);
    client->setCallback([this](char *topic, uint8_t *payload, unsigned int length) {
    callback(topic, payload, length);
    });
    if (!client->connected()) {
        reconnect();
    }
}

void MqttClient::reconnect() {
   while (!client->connected()) {
    Serial.print("Attempting MQTT connection... ");
    // Create a random client ID
    String clientId = "ESP8266Client-";
    clientId += String(random(0xffff), HEX);
    // Attempt to connect
    if (client->connect(clientId.c_str())) {
      Serial.println("connected.");
      // Once connected, publish an announcement...
      //client.publish("outTopic", "hello world");
      // ... and resubscribe
      //client.subscribe("inTopic");
      //client->subscribe(topicEntrada);
      //client->subscribe(topicSalida);   
      client->subscribe(topicEntrada);
      client->subscribe(topicSalida);
      
    } else {
      Serial.print("Failed, rc = ");
      Serial.print(client->state());
      Serial.println(". Try again in 5 seconds.");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}

void MqttClient::Publish(float t) {
  msg.resize(MSG_BUFFER_SIZE);
  snprintf (msg.data(), MSG_BUFFER_SIZE, "{\"dispositivo\":\"Refrigerador 1\",\"tipo\":\"Temperatura\",\"dato\":%.2f}",t* 1.0);
  client->publish(topicEntrada, msg.data());
}

void MqttClient::callback(char *topic, byte *payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
}
