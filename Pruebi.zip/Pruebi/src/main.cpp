#include <Arduino.h>
#include "CustomWiFi.h"
#include <WiFi.h>
#include "MqttClient.h"


// put function declarations here:
int myFunction(int, int);
CustomWiFi myWiFi("LaRome", "luisalbertorodriguez");
MqttClient mqtt("equipoPATO","equipoPATO");

//const char *topicEntrada, const char *topicSalida
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  int result = myFunction(2, 3);
  delay(5000);
  myWiFi.connect();
  delay(3000);
  mqtt.setup();
}

void loop() {
  if (myWiFi.isConnected()) {
    int result = myFunction(2, 3);
    //mqtt.client_loop();
    Serial.println(result);
  }
}
//gfvjhvbjknjbhvbjbvgc ghjihvgc ghjiokjhvgc 
// put function definitions here:
int myFunction(int x, int y) {
  return x + y;
}