#include "CustomWiFi.h"
#include <WiFi.h>

CustomWiFi::CustomWiFi(const char* ssid, const char* password) {
  _ssid = ssid;
  _password = password;
}

void CustomWiFi::connect() {
  WiFi.begin(_ssid, _password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi!");
}

bool CustomWiFi::isConnected() {
  return (WiFi.status() == WL_CONNECTED);
}